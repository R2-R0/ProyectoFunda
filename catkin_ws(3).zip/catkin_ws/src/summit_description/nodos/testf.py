#!/usr/bin/env python

import numpy as np


sin = np.sin; cos = np.cos; pi = np.pi

# Variables del robot movil
L=0.2225  ; l=0.2045 ; r = 0.127

A = np.array([[ 1, 1, 1,  1],
              [-1, 1, 1, -1],
              [-1/L+l,1/L+l,-1/L+l,1/L+l]])

fk = (r/4)*A

print fk

print np.transpose(A)

# Cinematica directa
def carFKine(dphi):
    Twist = fk*dphi
    return Twist

# Cinematica inversa
def carInvKine(Twist):
    dphi = np.linalg.pinv(A)*Twist
    return dphi
