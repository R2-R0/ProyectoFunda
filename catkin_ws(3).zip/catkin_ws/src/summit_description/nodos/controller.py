#!/usr/bin/env python
 
import rospy
import numpy as np
from sensor_msgs.msg import JointState
from std_msgs.msg import String
from functions import *
from geometry_msgs.msg import *
from nav_msgs.msg import Odometry
import actionlib
from control_msgs.msg import *
from trajectory_msgs.msg import *
 

sin = np.sin; cos = np.cos; pi = np.pi


# Variables del robot movil
L=0.2225  ; l=0.2045 ; r = 0.127
A = np.array([[ 1, 1, 1,  1],
              [-1, 1, 1, -1],
              [-1/L+l,1/L+l,-1/L+l,1/L+l]])
fk = (r/4)*A

# Cinematica directa
def carFKine(dphi):
    Twist = fk*dphi
    return Twist

# Cinematica inversa
def carInvKine(Twist):
    dphi = np.linalg.pinv(A)*Twist
    return dphi

# Control de posicion
def posControl(x, xd, k):
    e = xd - x

    #ley simple de control
    Twist = k*(xd - x)

    return Twist, e


#def callback_setpoint(msg):
    #global setpoint


def callback(msg):
    global pose
    global angle
    global theta
    pose  = msg.pose.pose.position
    angle = msg.pose.pose.orientation
    theta = np.arctan2(angle.z,angle.w)*2
    twist_u, er = posControl(np.array([pose.x,pose.y,theta]), np.array([3,4,1]), np.array([0.5,0.5,0.08]))
    twist_state.linear  =  Vector3(twist_u[0],twist_u[1],0)
    twist_state.angular =  Vector3(0,0,twist_u[2])
    pub.publish(twist_state)
    print "  x    :   " + str(pose.x)
    print "  y    :   " + str(pose.y)
    print "theta  :   "  + str(theta)

    # Wait for the next iteration

if __name__ == '__main__':

    rospy.init_node("controlador")
    pub = rospy.Publisher('/cmd_vel', Twist, queue_size=1000)
    rospy.Subscriber("/odom", Odometry,callback)
    #rospy.Subscriber("/setpoint", oint,callback_setpoint)

    twist_state = Twist()

    twist_state.linear  =  Vector3(0,0,0)
    twist_state.angular =  Vector3(0,0,0)
    pub.publish(twist_state)
    rate = rospy.Rate(10)

    rospy.spin()

