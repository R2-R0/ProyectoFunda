#!/usr/bin/env python
import time
import rospy
import actionlib
from sensor_msgs.msg import JointState
from std_msgs.msg import String
from control_msgs.msg import *
from trajectory_msgs.msg import *
 
global press_key
press_key = "0"
 
def callback(msg):
 
    global press_key
    press_key = msg.data

print 
"hola" 
 
if __name__ == '__main__':
    
    rospy.init_node("nodo_gazebo", disable_signals=True)
    pub = rospy.Publisher('joints', JointState, queue_size=1000)
    rospy.Subscriber("keys", String, callback)
    robot_client = actionlib.SimpleActionClient('follow_joint_trajectory', FollowJointTrajectoryAction)
 
    print "Waiting for server..."
    robot_client.wait_for_server()
    print "Connected to server"
 
    # Joint names
    jnames = ['summit_front_right_wheel_joint', 'summit_front_left_wheel_joint', 'summit_back_left_wheel_joint','summit_back_right_wheel_joint']

    # Initial configuration
    vel = [0,0,0,0]
    var = [0,0,0,0]
    q   = [0,0,0,0]
 
    # Object (message) whose type is JointState
    jstate = JointState()
    # Set values to the message
    jstate.header.stamp = rospy.Time.now()
    jstate.name = jnames
    # Add the head joint value (with value 0) to the joints
    jstate.position = q


    g = FollowJointTrajectoryGoal()
    g.trajectory = JointTrajectory()
    g.trajectory.joint_names = joint_names
 
    # Initial position
    g.trajectory.points = [ JointTrajectoryPoint(positions=q, velocities=[0]*6,time_from_start=rospy.Duration(2.0))]
    robot_client.send_goal(g)
    robot_client.wait_for_result()
    rospy.sleep(1)
    
    rate = rospy.Rate(10)
    while not rospy.is_shutdown():
        robot_client.cancel_goal()
        # Current time (needed for ROS)
        jstate.header.stamp = rospy.Time.now()
        # Modification of the motion
        
        var1 = 0.1

        if (press_key == "q"):
            vel[0] = vel[0] + var1
        if (press_key == "a"):
            vel[0] = vel[0] - var1
        if (press_key == "w"):
            vel[1] = vel[1] + var1
        if (press_key == "s"):
            vel[1] = vel[1] - var1
        if (press_key == "e"):
            vel[2] = vel[2] + var1
        if (press_key == "d"):
            vel[2] = vel[2] - var1
        if (press_key == "r"):
            vel[3] = vel[3] + var1
        if (press_key == "f"):
            vel[3] = vel[3] - var1

        q[0] = q[0] + (vel[0] * 0.1)
        q[1] = q[1] + (vel[1] * 0.1)
        q[2] = q[2] + (vel[2] * 0.1)
        q[3] = q[3] + (vel[3] * 0.1)
 
        jstate.position = q
        pub.publish(jstate)

        g.trajectory.points = [ JointTrajectoryPoint(positions=q, velocities=[0]*6, time_from_start=rospy.Duration(0.008))]
        robot_client.send_goal(g)
        robot_client.wait_for_result()
        #print 'keys:', press_key
        rate.sleep()
 
    robot_client.cancel_goal()
