#!/usr/bin/env python

import rospy
import numpy as np
import math

from geometry_msgs.msg import *
from nav_msgs.msg import Odometry
from tf import transformations

from control_msgs.msg import *
from trajectory_msgs.msg import *

from functions import *

cos = np.cos
sin = np.sin

state_           =   0
yaw_precition_   =   0.05
pos_precition    =   0.1
K_               =   np.array([0.5,0.5,0.2])
pose_x  = 0
pose_y  = 0
pose_th = 0
pose_th2 = 0


def callback_odom(msg):
    global pose_x
    global pose_y
    global pose_th
    global pose_th2

    pose_x = msg.pose.pose.position.x
    pose_y = msg.pose.pose.position.y

    quaternion = (msg.pose.pose.orientation.x,
                  msg.pose.pose.orientation.y,
                  msg.pose.pose.orientation.z,
                  msg.pose.pose.orientation.w)
    (roll, pitch, yaw) = transformations.euler_from_quaternion(quaternion)
    pose_th  = yaw
    
    if pose_th>=0:
        pose_th2 = pose_th
    else:
        pose_th2 = pose_th + 2*(math.pi)
    #print(pose_th2)

def normalize_angle(angle):
    if(math.fabs(angle)>math.pi):
        angle = angle - (2 * math.pi * angle) / (math.fabs(angle))
    return angle

def change_state(state):
    global state_
    state_ = state
    print('state changed')


def controller(desired_pose):
    global pose_x,pose_y,pose_th,pose_th2, yaw_precition_, pos_precition,state_,k_

    jstate.header.stamp = rospy.Time.now()

    err_pose_x    =   desired_pose[0] - pose_x
    err_pose_y    =   desired_pose[1] - pose_y
    err_pose_th   =   normalize_angle(desired_pose[2] - pose_th)

    robot_err_x   =   (cos(pose_th) * err_pose_x)    +   (sin(pose_th)  *  err_pose_y)
    robot_err_y   =   -(sin(pose_th) * err_pose_x)   +   (cos(pose_th)  *  err_pose_y)

    twist_msg = Twist()

    there_is_error = False

    if math.fabs(err_pose_th) > yaw_precition_:
        twist_msg.angular.z = K_[2] * err_pose_th
        there_is_error = True
    if math.fabs(err_pose_x) > pos_precition:
        twist_msg.linear.x  = K_[0] * robot_err_x
        there_is_error = True
    if math.fabs(err_pose_y) > pos_precition:
        twist_msg.linear.y  = K_[1] * robot_err_y
        there_is_error = True
    pub.publish(twist_msg)

    if not there_is_error:
        print('Arrived')
        change_state(1)

    
    # Kinematic control law for the pose (complete here)
    # --------------------------------------------------
    k = 100
    f = fkine_acm(q)
    xp = f[0:3, 3]
    J = jacobian_pose(q)

    Q = rot2quat(f[0:3, 0:3]); wQ = Q[0]; eQ = Q[1:].reshape((3,1))
    Qd = xd[3:]; wd = Qd[0]; ed = Qd[1:].reshape((3,1))
    we = wQ*wd + np.dot(ed.T, eQ)
    ee = -wd*eQ + wQ*ed - np.cross(ed.flatten(),eQ.flatten())
    e0 = np.array([we[0,0]-1, ee[0,0], ee[0,1], ee[0,2]]); e0 = e0.reshape((4,1))
    xd = xd.reshape((7,1))
    difx = xp - xd[0:3].flatten()
    e = np.vstack((difx.reshape((3,1)), e0))
    de = -k*e

    dq = np.dot(np.linalg.pinv(J), de)
    q = q.reshape((5,1)) + dt*dq; q = q.flatten()
    # Current configuration trnaformation to current position
    T = fkine_acm(q)
    x = TF2xyzquat(T)
    # Publish the message
    jstate.position = q
    pub.publish(jstate)

def done():
    twist_msg= Twist()
    twist_msg.linear.x = 0.0
    twist_msg.linear.y = 0.0
    twist_msg.linear.z = 0.0
    pub.publish(twist_msg)

def main():
    global pub, active_

    rospy.init_node("controller")
    pub = rospy.Publisher('/cmd_vel', Twist, queue_size=1000)
    rospy.Subscriber("/odom", Odometry,callback_odom)
    pub2 = rospy.Publisher('joints', JointState, queue_size=1000)
    #sub_setpoint = rospy.Subscriber("/setpoint", Point,callback_setpoint)
    

    # Joint names
    jnames = ['summit_front_left_wheel_joint', 'summit_front_right_wheel_joint', 'summit_back_left_wheel_joint',
                'summit_back_right_wheel_joint', 'base_link__link_01', 'link_01__link_02', 'link_02__link_03',
                'link_03__link_04', 'link_04__link_05', 'link_05__link_06']
    # Joint Configuration
    q = [0.0, 1, 1.7, -1.2, 0.0]
    qq = [0,0,0,0,q[0],q[1],q[2],q[3],q[4],0]

    # Desired pose
    ang = pi/3
    Rd = np.array([[0,1,0],[1,0,0],[0,0,1]])
    qd = rot2quat(Rd)
    # Find an xd that the robot can reach
    xd = np.array([0.4, 0.4, 0.4, qd[0], qd[1], qd[2], qd[3]])
    #xd  = np.array([0.5, 0.5, 0.6, np.cos(ang/2.0), 0, 0, np.sin(ang/2.0)])
    # Initial configuration
    q0  = np.array([0.0, -1.0, 1.7, -2.2, 0])

    # Resulting initial pose (end effector with respect to the base link)
    T = fkine_acm(q0)
    x0 = TF2xyzquat(T)


    # Instance of the JointState message
    jstate = JointState()
    # Values of the message
    jstate.header.stamp = rospy.Time.now()
    jstate.name = jnames
    # Add the head joint value (with value 0) to the joints
    jstate.position = q0

    # Frequency (in Hz) and control period 
    freq = 200
    dt = 1.0/freq
    rate = rospy.Rate(freq)

    # Initial joint configuration
    q = copy(q0)
    x = copy(x0)
    quat = x[3:5]
    # Initialize the derror vector (derivative of the error)
    derror = np.zeros(5)

    desired_pose = np.array([-2,5,4])

    while not rospy.is_shutdown():

        k = 100
        f = fkine_acm(q)
        xp = f[0:3, 3]
        J = jacobian_pose(q)

        Q = rot2quat(f[0:3, 0:3]); wQ = Q[0]; eQ = Q[1:].reshape((3,1))
        Qd = xd[3:]; wd = Qd[0]; ed = Qd[1:].reshape((3,1))
        we = wQ*wd + np.dot(ed.T, eQ)
        ee = -wd*eQ + wQ*ed - np.cross(ed.flatten(),eQ.flatten())
        e0 = np.array([we[0,0]-1, ee[0,0], ee[0,1], ee[0,2]]); e0 = e0.reshape((4,1))
        xd = xd.reshape((7,1))
        difx = xp - xd[0:3].flatten()
        e = np.vstack((difx.reshape((3,1)), e0))
        de = -k*e

        dq = np.dot(np.linalg.pinv(J), de)
        q = q.reshape((5,1)) + dt*dq; q = q.flatten()
        # Current configuration trnaformation to current position
        T = fkine_acm(q)
        x = TF2xyzquat(T)
        # Publish the message
        jstate.position = q
        pub.publish(jstate)
        bmarker_desired.setPose(xd)
        bmarker_current.setPose(x)
        # Wait for the next iteration
        rate.sleep()

        if state_ == 0:
            
            controller(desired_pose)
        else:
            done()
        rate.sleep()

if __name__ == '__main__':
    main()