#!/usr/bin/env python
import rbdl
import numpy as np


# Lectura del modelo del robot a partir de URDF (parsing)
modelo = rbdl.loadModel('../urdf/mrm.urdf')
# Grados de libertad
ndof = modelo.q_size

# Configuracion articular
q = np.array([0.5, 0.2, 0.3, 0.8, 0.5])
# Velocidad articular
dq = np.array([0.8, 0.7, 0.8, 0.6, 0.9])
# Aceleracion articular
ddq = np.array([0.2, 0.5, 0.4, 0.3, 1.0])

# Arrays numpy
zeros = np.zeros(ndof)          # Vector de ceros
tau   = np.zeros(ndof)          # Para torque
g     = np.zeros(ndof)          # Para la gravedad
c     = np.zeros(ndof)          # Para el vector de Coriolis+centrifuga
M     = np.zeros([ndof, ndof])  # Para la matriz de inercia
e     = np.eye(5)               # Vector identidad

# Torque dada la configuracion del robot
rbdl.InverseDynamics(modelo, q, dq, ddq, tau)

# Parte 1: Calcular vector de gravedad, vector de Coriolis/centrifuga,
# y matriz M usando solamente InverseDynamics

# gravedad
rbdl.InverseDynamics(modelo, q, zeros, zeros, g)

# coriolis
rbdl.InverseDynamics(modelo, q, dq, zeros, c)
c = c - g

# matriz inercia
rbdl.InverseDynamics(modelo, q, zeros, e[0,:], M[0,:])
rbdl.InverseDynamics(modelo, q, zeros, e[1,:], M[1,:])
rbdl.InverseDynamics(modelo, q, zeros, e[2,:], M[2,:])
rbdl.InverseDynamics(modelo, q, zeros, e[3,:], M[3,:])
rbdl.InverseDynamics(modelo, q, zeros, e[4,:], M[4,:])

M = M - g

# Parte 2: Calcular M y los efectos no lineales b usando las funciones
# CompositeRigidBodyAlgorithm y NonlinearEffects. Almacenar los resultados
# en los arreglos llamados M2 y b2
b2 = np.zeros(ndof)          # Para efectos no lineales
M2 = np.zeros([ndof, ndof])  # Para matriz de inercia
 
rbdl.CompositeRigidBodyAlgorithm(modelo, q, M2)
print("Matriz de inercia")
print(M2)
 
rbdl.NonlinearEffects(modelo, q, dq, b2)
print("Efectos no lineales usando NonlinearEffects")
print(b2)
 
# Parte 2: Verificacion de valores
 
print("Verificacion b = c + g")
print("Usando la primera parte")
print(np.round(c+g,2))
print("Usando NonlinearEffects")
print(np.round(b2,2))
 
print("Verificacion Matriz de Inercia")
print("Usando la primera parte")
print(np.round(M,2))
print("Usando NonlinearEffects")
print(np.round(M2,2))
 
# Parte 3: Verificacion de la expresion de la dinamica
 
print("Torque calculado")
print(tau)
 
tau_verificado = M.dot(ddq) + c.dot(dq) + g
print("Torque verificado")
print(tau_verificado)
