#!/usr/bin/env python

import rospy
import numpy as np
import math

from geometry_msgs.msg import *
from nav_msgs.msg import Odometry
from tf import transformations

from control_msgs.msg import *
from trajectory_msgs.msg import *

cos = np.cos
sin = np.sin

state_           =   0
yaw_precition_   =   0.05
pos_precition    =   0.1
K_               =   np.array([0.5,0.5,0.2])
pose_x  = 0
pose_y  = 0
pose_th = 0
pose_th2 = 0


def callback_odom(msg):
    global pose_x
    global pose_y
    global pose_th
    global pose_th2

    pose_x = msg.pose.pose.position.x
    pose_y = msg.pose.pose.position.y

    quaternion = (msg.pose.pose.orientation.x,
                  msg.pose.pose.orientation.y,
                  msg.pose.pose.orientation.z,
                  msg.pose.pose.orientation.w)
    (roll, pitch, yaw) = transformations.euler_from_quaternion(quaternion)
    pose_th  = yaw
    
    if pose_th>=0:
        pose_th2 = pose_th
    else:
        pose_th2 = pose_th + 2*(math.pi)
    #print(pose_th2)

def normalize_angle(angle):
    if(math.fabs(angle)>math.pi):
        angle = angle - (2 * math.pi * angle) / (math.fabs(angle))
    return angle

def change_state(state):
    global state_
    state_ = state
    print('state changed')


def controller(desired_pose):
    global pose_x,pose_y,pose_th,pose_th2, yaw_precition_, pos_precition,state_,k_

    jstate.header.stamp = rospy.Time.now()

    err_pose_x    =   desired_pose[0] - pose_x
    err_pose_y    =   desired_pose[1] - pose_y
    err_pose_th   =   normalize_angle(desired_pose[2] - pose_th)

    robot_err_x   =   (cos(pose_th) * err_pose_x)    +   (sin(pose_th)  *  err_pose_y)
    robot_err_y   =   -(sin(pose_th) * err_pose_x)   +   (cos(pose_th)  *  err_pose_y)

    twist_msg = Twist()

    there_is_error = False

    if math.fabs(err_pose_th) > yaw_precition_:
        twist_msg.angular.z = K_[2] * err_pose_th
        there_is_error = True
    if math.fabs(err_pose_x) > pos_precition:
        twist_msg.linear.x  = K_[0] * robot_err_x
        there_is_error = True
    if math.fabs(err_pose_y) > pos_precition:
        twist_msg.linear.y  = K_[1] * robot_err_y
        there_is_error = True
    pub.publish(twist_msg)

    if not there_is_error:
        print('Arrived')
        change_state(1)


def done():
    twist_msg= Twist()
    twist_msg.linear.x = 0.0
    twist_msg.linear.y = 0.0
    twist_msg.linear.z = 0.0
    pub.publish(twist_msg)

def main():
    global pub, active_

    rospy.init_node("controller")
    pub = rospy.Publisher('/cmd_vel', Twist, queue_size=1000)
    rospy.Subscriber("/odom", Odometry,callback_odom)
    #pub2 = rospy.Publisher('joints', JointState, queue_size=1000)
    #sub_setpoint = rospy.Subscriber("/setpoint", Point,callback_setpoint)
    

    while not rospy.is_shutdown():
        if state_ == 0:
            
            controller(desired_pose)
        else:
            done()
        rate.sleep()

if __name__ == '__main__':
    main()