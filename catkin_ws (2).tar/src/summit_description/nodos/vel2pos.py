#!/usr/bin/env python
 
import rospy
from sensor_msgs.msg import JointState
from std_msgs.msg import String

global press_key
press_key = "0"
 
def callback(msg):
 
    global press_key
    press_key = msg.data
 
rospy.init_node("nodo2")
rospy.Subscriber("/keys", String, callback)
pub = rospy.Publisher('joints', JointState, queue_size=1000)
#bmarker = BallMarker(color['GREEN'])
 
# Joint names
jnames = ['summit_front_right_wheel_joint', 'summit_front_left_wheel_joint', 'summit_back_left_wheel_joint','summit_back_right_wheel_joint']

vel = [0,0,0,0]
var = [0,0,0,0]
q   = [0,0,0,0] 

# Object (message) whose type is JointState
jstate = JointState()
# Set values to the message
jstate.header.stamp = rospy.Time.now()
jstate.name = jnames
# Add the head joint value (with value 0) to the joints
jstate.position = q
 
# Loop rate (in Hz)
rate = rospy.Rate(10)
# Continuous execution loop
while not rospy.is_shutdown():
    
    # Current time (needed for ROS)
    jstate.header.stamp = rospy.Time.now()
    # Publish the message
    #print 'keys:',
    var1=0.1
    
    if(press_key=="q"):
        vel[0]=vel[0]+var1
    if(press_key=="a"):
        vel[0]=vel[0]-var1
    if(press_key=="w"):
        vel[1]=vel[1]+var1
    if(press_key=="s"):
        vel[1]=vel[1]-var1
    if(press_key=="e"):
        vel[2]=vel[2]+var1
    if(press_key=="d"):
        vel[2]=vel[2]-var1
    if(press_key=="r"):
        vel[3]=vel[3]+var1
    if(press_key=="f"):
        vel[3]=vel[3]-var1

    q[0]=q[0]+(vel[0]*0.1)
    q[1]=q[1]+(vel[1]*0.1)
    q[2]=q[2]+(vel[2]*0.1)
    q[3]=q[3]+(vel[3]*0.1)

    jstate.position = q
    pub.publish(jstate)

    # Wait for the next iteration
    rate.sleep()
