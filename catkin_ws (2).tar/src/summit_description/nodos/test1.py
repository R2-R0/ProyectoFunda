#!/usr/bin/env python
 
import rospy
from sensor_msgs.msg import JointState
from std_msgs.msg import String

global press_key
press_key = "0"
 
def callback(msg):
 
    global press_key
    press_key = msg.data
 
rospy.init_node("nodo1")
rospy.Subscriber("/keys", String, callback)
pub = rospy.Publisher('joints', JointState, queue_size=1000)
#bmarker = BallMarker(color['GREEN'])
 
# Joint names
jnames = ['summit_front_right_wheel_joint', 'summit_front_left_wheel_joint', 'summit_back_left_wheel_joint','summit_back_right_wheel_joint']

q = [0,0,0,0] 

# Object (message) whose type is JointState
jstate = JointState()
# Set values to the message
jstate.header.stamp = rospy.Time.now()
jstate.name = jnames
# Add the head joint value (with value 0) to the joints
jstate.position = q
 
# Loop rate (in Hz)
rate = rospy.Rate(10)
# Continuous execution loop
while not rospy.is_shutdown():
    
    # Current time (needed for ROS)
    jstate.header.stamp = rospy.Time.now()
    # Publish the message
    #print 'keys:',
    var=0.1
    if(press_key=="q"):
        q[0]=q[0]+var
    if(press_key=="a"):
        q[0]=q[0]-var
    if(press_key=="w"):
        q[1]=q[1]+var
    if(press_key=="s"):
        q[1]=q[1]-var
    if(press_key=="e"):
        q[2]=q[2]+var
    if(press_key=="d"):
        q[2]=q[2]-var
    if(press_key=="r"):
        q[3]=q[3]+var
    if(press_key=="f"):
        q[3]=q[3]-var

    jstate.position = q
    pub.publish(jstate)

    # Wait for the next iteration
    rate.sleep()
