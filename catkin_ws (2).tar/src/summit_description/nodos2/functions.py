import numpy as np
from copy import copy

cos=np.cos; sin=np.sin; pi=np.pi

def dh(theta, d, alpha, a):
    """
    Calcular la matriz de transformacion homogenea asociada con los parametros
    de Denavit-Hartenberg.
    Los valores d, theta, a, alpha son escalares.
    """
    #theta = np.deg2rad(theta)
    #alpha = np.deg2rad(alpha)
        
    # Escriba aqui la matriz de transformacion homogenea en funcion de los valores de d, theta, a, alpha
    T = np.array([[cos(theta), -1*cos(alpha)*sin(theta), sin(alpha)*sin(theta), a*cos(theta)],
                      [sin(theta), cos(alpha)*cos(theta), -1*sin(alpha)*cos(theta), a*sin(theta)],
                      [0, sin(alpha), cos(alpha), d],
                      [0, 0, 0, 1]])
    return T
    
    

def fkine_acm(q):
    """
    Calcular la cinematica directa del robot ACM dados sus valores articulares. 
    q es un vector numpy de la forma [q1, q2, q3, q4]
    """
    # Longitudes (en metros)
    L1 = 0.825
    L2 = 1.375

 
    # Matrices DH (completar), emplear la funcion dh con los parametros DH para cada articulacion
    T01=dh(pi/2+q[0], L1, pi/2, 0)
    T12=dh(pi/2+q[1], 0, pi/2, 0)
    T23=dh(pi+q[2], L2, pi/2, 0)
    T34=dh(q[3], 0, pi/2, 0)
    T45=dh(pi/2+q[4],0,pi,0)

    # Efector final con respecto a la base
    T = T01.dot(T12).dot(T23).dot(T34).dot(T45)
    return T

def jacobian_acm(q, delta=0.0001):
    """
    Jacobiano analitico para la posicion. Retorna una matriz de 3x5 y toma como
    entrada el vector de configuracion articular q=[q1, q2, q3, q4, q5]
    """
    # Crear una matriz 3x5
    J = np.zeros((3,5))

    # Transformacion homogenea inicial (usando q)
    T0 = fkine_acm(q)
    x0 = T0[0:3, 3]; x0 = x0.T

    # Iteracion para la derivada de cada columna
    for i in range(5):     #xrange(4)
        # Copiar la configuracion articular inicial
        dq = copy(q)
        # Incrementar la articulacion i-esima usando un delta
        dq[i] = dq[i] + delta
        # Transformacion homogenea luego del incremento (q+delta)
        T = fkine_acm(dq)
        x = T[0:3, 3]; x = x.T
        # Aproximacion del Jacobiano de posicion usando diferencias finitas
        J[0:3, i] = (T[0:3, 3] - T0[0:3, 3])/delta
    return J


def ikine_acm(xdes, q0):
    """
    Calcular la cinematica inversa de ACM numericamente a partir de la configuracion articular inicial de q0. 
    Metodo de Newton
    """
    epsilon  = 0.001
    max_iter = 1000
    delta    = 0.00001

    q  = copy(q0)
    for i in range(max_iter):
        f = fkine_acm(q)
        J = jacobian_acm(q)

        e = xdes - f[0:3, 3]
        q = q + np.dot(np.linalg.pinv(J), e)

        # Norma del error
        enorm = np.linalg.norm(e)
        print("Error en la iteracion {}: {}".format(i, np.round(enorm, 4)))
        
        # Condicion de termino
        if np.linalg.norm(e) < epsilon:
            break
    return q


def jacobian_pose(q, delta=0.0001):
    """
    Jacobiano analitico para la posicion y orientacion (usando un
    cuaternion). Retorna una matriz de 7x5 y toma como entrada el vector de
    configuracion articular q=[q1, q2, q3, q4, q5]

    """
    J = np.zeros((7,5))
    # Implementar este Jacobiano aqui

    # Transformacion homogenea inicial (usando q)
    T0 = fkine_acm(q)
    x0 = T0[0:3, 3]
    Q0 = rot2quat(T0[0:3, 0:3])

    # Iteracion para la derivada de cada columna
    for i in range(5):     #xrange(5)
        # Copiar la configuracion articular inicial
        dq = copy(q)
        # Incrementar la articulacion i-esima usando un delta
        dq[i] = dq[i] + delta
        # Transformacion homogenea luego del incremento (q+delta)
        T = fkine_acm(dq)
        x = T[0:3, 3]
        Q = rot2quat(T[0:3, 0:3])
        # Aproximacion del Jacobiano de posicion usando diferencias finitas
        J[0:3, i] = (x - x0)/delta
        J[3:7, i] = (Q - Q0)/delta
    return J


def rot2quat(R):
    """
    Convertir una matriz de rotacion en un cuaternion

    Entrada:
      R -- Matriz de rotacion
    Salida:
      Q -- Cuaternion [ew, ex, ey, ez]

    """
    dEpsilon = 1e-6
    quat = 4*[0.,]

    quat[0] = 0.5*np.sqrt(R[0,0]+R[1,1]+R[2,2]+1.0)
    if ( np.fabs(R[0,0]-R[1,1]-R[2,2]+1.0) < dEpsilon ):
        quat[1] = 0.0
    else:
        quat[1] = 0.5*np.sign(R[2,1]-R[1,2])*np.sqrt(R[0,0]-R[1,1]-R[2,2]+1.0)
    if ( np.fabs(R[1,1]-R[2,2]-R[0,0]+1.0) < dEpsilon ):
        quat[2] = 0.0
    else:
        quat[2] = 0.5*np.sign(R[0,2]-R[2,0])*np.sqrt(R[1,1]-R[2,2]-R[0,0]+1.0)
    if ( np.fabs(R[2,2]-R[0,0]-R[1,1]+1.0) < dEpsilon ):
        quat[3] = 0.0
    else:
        quat[3] = 0.5*np.sign(R[1,0]-R[0,1])*np.sqrt(R[2,2]-R[0,0]-R[1,1]+1.0)

    return np.array(quat)


def TF2xyzquat(T):
    """
    Convert a homogeneous transformation matrix into the a vector containing the
    pose of the robot.

    Input:
      T -- A homogeneous transformation
    Output:
      X -- A pose vector in the format [x y z ew ex ey ez], donde la first part
           is Cartesian coordinates and the last part is a quaternion
    """
    quat = rot2quat(T[0:3,0:3])
    res = [T[0,3], T[1,3], T[2,3], quat[0], quat[1], quat[2], quat[3]]
    return np.array(res)


def skew(w):
    R = np.zeros([3,3])
    R[0,1] = -w[2]; R[0,2] = w[1]
    R[1,0] = w[2];  R[1,2] = -w[0]
    R[2,0] = -w[1]; R[2,1] = w[0]
    return R

